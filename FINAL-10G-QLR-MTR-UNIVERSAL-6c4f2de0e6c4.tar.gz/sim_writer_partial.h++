
// HARDWARE PARTIAL - SIM MACHINE - H++
// PUF 368f9466 | Tunnel 305aefa46543 | Future build partial
// Compatible to ATtiny85 + SIM900 - but software works without SIM now
HARDWARE_SIM_PARTIAL {
  CHIP: ATtiny85 + SIM900
  PUF: 368f9466-SIM-PARTIAL
  TUNNEL: 305aefa46543
  DIAL: *629*
  LANGUAGE: H++
  STATUS: PARTIAL CODE - Software *629* works without SIM hardware now
  FUNCTION:
    fn write_sim_partial() -> SIM {
        sim = SIM::new(PUF: 368f9466);
        sim.write_puf(368f9466);
        sim.dial(*629*);
        sim.connect(MainTunnel: 305aefa46543);
        // Hardware not needed for current proof, but code present for future
        return sim;
    }
}
